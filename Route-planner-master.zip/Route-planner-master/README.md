# Route-planner
In this project we used use A* search to implement a "Google-maps" style route planning algorithm.
